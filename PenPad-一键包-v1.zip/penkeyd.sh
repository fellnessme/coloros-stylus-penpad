#!/system/bin/sh
# penkeyd.sh —— 笔键守护
#
# 系统的笔键在派发前就被消费了，只有 shell/root 读 /dev/input 才能拿到。
# 本脚本读出按键后转发成本应用内广播。
#
# 用法： sh penkeyd.sh [设备名关键字]

PATTERN="${1:-Consumer Control}"
ACTION="com.aclaniakea.penpad.PENKEY"
COMP="com.aclaniakea.penpad/.PenKeyReceiver"
LOG=/data/local/tmp/penkeyd.log
PIDFILE=/data/local/tmp/penkeyd.pid
READ_TIMEOUT=60          # 单次读取最长等待，超时就重找节点（治"进程活着但收不到按键"）

log() { echo "$(date '+%H:%M:%S') $*" >> "$LOG"; }

# 单实例
if [ -f "$PIDFILE" ]; then
    OLD=$(cat "$PIDFILE" 2>/dev/null)
    if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
        log "another instance ($OLD) running, exit"
        exit 0
    fi
fi
echo $$ > "$PIDFILE"

find_node() {
    /system/bin/getevent -pl 2>/dev/null | awk -v pat="$PATTERN" '
        /^add device/ { dev=$4 }
        index($0, "name:") && index($0, pat) { print dev; exit }
    '
}

NODE=""
i=0
while [ $i -lt 15 ]; do
    NODE=$(find_node)
    [ -n "$NODE" ] && break
    i=$((i+1))
    sleep 2
done
if [ -z "$NODE" ]; then
    log "device '$PATTERN' not found; waiting"
    while [ -z "$NODE" ]; do sleep 5; NODE=$(find_node); done
fi
log "=== daemon start pid=$$ node=$NODE ==="

while true; do
    # 带超时：60 秒没事件就认为节点卡死，重新查找
    line=$(/system/bin/timeout $READ_TIMEOUT /system/bin/getevent -c 1 "$NODE" 2>/dev/null)

    if [ -z "$line" ]; then
        NEW=$(find_node)
        if [ -z "$NEW" ] || [ "$NEW" != "$NODE" ]; then
            NODE=""
            while [ -z "$NODE" ]; do sleep 3; NODE=$(find_node); done
            log "rebound to $NODE"
        fi
        continue
    fi

    case "$line" in
        *000c0600*) am broadcast -n "$COMP" -a "$ACTION" --ei code 0 >/dev/null 2>&1 ;;
        *000c0601*) am broadcast -n "$COMP" -a "$ACTION" --ei code 1 >/dev/null 2>&1 ;;
        *000c0602*) am broadcast -n "$COMP" -a "$ACTION" --ei code 2 >/dev/null 2>&1 ;;
        *000c0604*) am broadcast -n "$COMP" -a "$ACTION" --ei code 4 >/dev/null 2>&1 ;;
    esac
done