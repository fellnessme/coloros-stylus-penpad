@echo off
setlocal
title PenPad Setup
if "%~1"=="monitor" goto :mon
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0penpad-setup.ps1"
goto :eof
:mon
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0penpad-setup.ps1" -Monitor