# PenPad 一键安装器
#
# 用法：
#   双击「一键启动.bat」
#   或： powershell -ExecutionPolicy Bypass -File penpad-setup.ps1
#   带监控： powershell -ExecutionPolicy Bypass -File penpad-setup.ps1 -Monitor

param(
    [switch]$Monitor,
    [int]$IntervalSec = 20
)

$ErrorActionPreference = 'Continue'
$Root = $PSScriptRoot
$OkMark = '  [OK]  '
$NoMark = '  [--]  '
$FailMark = '  [!!]  '

function Line($t) { Write-Host $t }
function Head($t) { Write-Host ''; Write-Host "=== $t ===" -ForegroundColor Cyan }

# ---------------------------------------------------------------- 找 adb
$adb = $null
$cands = @(
    $env:ADB,
    (Join-Path $Root 'platform-tools\adb.exe'),
    (Join-Path $Root 'adb.exe'),
    'adb'
)
foreach ($c in $cands) {
    if (-not $c) { continue }
    if ($c -eq 'adb') {
        $cmd = Get-Command adb -ErrorAction SilentlyContinue
        if ($cmd) { $adb = $cmd.Source; break }
    } elseif (Test-Path $c) { $adb = $c; break }
}
if (-not $adb) {
    Line ''
    Line '  [!!] 找不到 adb。'
    Line '       请把 platform-tools 文件夹放在本文件旁边，'
    Line '       或安装 Android Platform Tools 并加入 PATH。'
    Line ''
    Read-Host '按回车退出'
    exit 1
}
Line ''
Line '  PenPad 一键安装器'
Line '  ------------------'
Line ("  adb: " + $adb)

# ---------------------------------------------------------------- 等设备
Head '等待平板连接'
& $adb wait-for-device 2>&1 | Out-Null
& $adb get-state 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Line "$FailMark 平板未连接，或没有授权 USB 调试"
    Read-Host '按回车退出'
    exit 1
}
$serial = (& $adb get-serialno 2>&1 | Out-String).Trim()
Line "$OkMark 已连接：$serial"

# ---------------------------------------------------------------- 推守护脚本
Head '安装笔键守护'
$localSh = Join-Path $Root 'penkeyd.sh'
if (-not (Test-Path $localSh)) {
    Line "$FailMark 缺少 penkeyd.sh（应该在和本文件同一个目录）"
} else {
    $remote = '/data/local/tmp/penkeyd.sh'
    & $adb push $localSh $remote 2>&1 | Out-Null
    & $adb shell chmod 755 $remote 2>&1 | Out-Null
    Line "$OkMark 已推送 penkeyd.sh"
}

# ---------------------------------------------------------------- 系统开关
Head '系统手写笔设置'
$before1 = (& $adb shell 'settings get global settings_enable_oppo_pencil' 2>&1 | Out-String).Trim()
& $adb shell 'settings put global settings_enable_oppo_pencil 1' 2>&1 | Out-Null
$after1 = (& $adb shell 'settings get global settings_enable_oppo_pencil' 2>&1 | Out-String).Trim()
if ($after1 -eq '1') { Line "$OkMark 笔开关 = 1（原来 $before1）" }
else { Line "$FailMark 笔开关设置失败，当前 = $after1" }

$before2 = (& $adb shell 'settings get global ipe_pencil_swipe_function' 2>&1 | Out-String).Trim()
& $adb shell 'settings put global ipe_pencil_swipe_function 1' 2>&1 | Out-Null
$after2 = (& $adb shell 'settings get global ipe_pencil_swipe_function' 2>&1 | Out-String).Trim()
if ($after2 -eq '1') { Line "$OkMark 全局批注（笔上滑）= 1（原来 $before2）" }
else { Line "$FailMark 全局批注设置失败，当前 = $after2" }

# ---------------------------------------------------------------- 悬浮窗
Head '悬浮窗权限'
& $adb shell "appops set com.aclaniakea.penpad SYSTEM_ALERT_WINDOW allow" 2>&1 | Out-Null
$ov = (& $adb shell "appops get com.aclaniakea.penpad SYSTEM_ALERT_WINDOW" 2>&1 | Out-String).Trim()
if ($ov -match 'allow') { Line "$OkMark 悬浮窗已允许" }
else { Line "$FailMark 悬浮窗设置失败：$ov" }

# ---------------------------------------------------------------- 无障碍
Head '无障碍服务'
$self = 'com.aclaniakea.penpad/com.aclaniakea.penpad.PenKeyService'
$cur = (& $adb shell 'settings get secure enabled_accessibility_services' 2>&1 | Out-String).Trim()
if ($cur -eq 'null') { $cur = '' }
if ($cur -notlike "*$self*") {
    $next = if ($cur -eq '') { $self } else { "$cur`:$self" }
    & $adb shell "settings put secure enabled_accessibility_services '$next'" 2>&1 | Out-Null
    Line "$OkMark 已加入无障碍列表"
} else {
    Line "$OkMark 已在无障碍列表中"
}
& $adb shell 'settings put secure accessibility_enabled 1' 2>&1 | Out-Null
Start-Sleep -Seconds 3
$bound = (& $adb shell 'dumpsys accessibility' 2>&1 | Out-String)
if ($bound -match 'PenKeyService') { Line "$OkMark 无障碍服务已绑定" }
else { Line "$NoMark 还没绑定（重启一次通常就好）" }

# ---------------------------------------------------------------- 启动守护
Head '启动笔键守护'
& $adb shell 'setsid sh /data/local/tmp/penkeyd.sh' 2>&1 | Out-Null
Start-Sleep -Seconds 3
$n = (& $adb shell 'ps -A 2>/dev/null | grep -c getevent' 2>&1 | Out-String).Trim()
if ($n -match '^[1-9]') { Line "$OkMark 守护已运行（getevent x$n）" }
else { Line "$FailMark 守护没起来，请确认笔已连接平板" }

# ---------------------------------------------------------------- 汇总
Head '完成'
Line ''
Line '  现在可以：'
Line '    · 用笔写字（带压感）'
Line '    · 笔从屏幕底边快速上滑 → 系统全局批注'
Line '    · 通知栏磁贴 → 开关全屏批注'
Line ''
if (-not $Monitor) {
    Line '  提示：加 -Monitor 参数可以让本脚本常驻监控守护进程。'
    Line ''
    Read-Host '按回车退出'
    exit 0
}

# ---------------------------------------------------------------- 监控模式
Head "监控模式（每 $IntervalSec 秒检查一次，关掉窗口即停止）"
$lastForce = [DateTime]::MinValue
while ($true) {
    Start-Sleep -Seconds $IntervalSec

    & $adb get-state 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { Line ('  [' + (Get-Date -Format 'HH:mm:ss') + '] 平板断开，等待重连…'); continue }

    $n = (& $adb shell 'ps -A 2>/dev/null | grep -c getevent' 2>&1 | Out-String).Trim()
    $wake = (& $adb shell "dumpsys power | grep -c mWakefulness=Awake" 2>&1 | Out-String).Trim()
    $ts = (Get-Date -Format 'HH:mm:ss')

    if ($wake -match '^[1-9]') {
        $force = ((Get-Date) - $lastForce).TotalMinutes -ge 5
        if ($n -notmatch '^[1-9]' -or $force) {
            $why = if ($n -notmatch '^[1-9]') { '守护已死' } else { '定时重启' }
            Line "  [$ts] $why，重新启动…"
            & $adb shell 'setsid sh /data/local/tmp/penkeyd.sh' 2>&1 | Out-Null
            $lastForce = Get-Date
            Start-Sleep -Seconds 2
            $n2 = (& $adb shell 'ps -A 2>/dev/null | grep -c getevent' 2>&1 | Out-String).Trim()
            Line "  [$ts] 已重启（getevent x$n2）"
        } else {
            Line "  [$ts] 正常（getevent x$n）"
        }
    } else {
        Line "  [$ts] 息屏，跳过"
    }
}
