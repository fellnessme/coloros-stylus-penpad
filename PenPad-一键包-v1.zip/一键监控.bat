@echo off
setlocal
title PenPad Setup
goto :mon
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0penpad-setup.ps1"
goto :eof
:mon
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0penpad-setup.ps1" -Monitor